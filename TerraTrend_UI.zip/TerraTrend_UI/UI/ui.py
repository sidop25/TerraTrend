from flask import Flask, render_template_string, request
import pandas as pd
import pickle
import numpy as np

app = Flask(__name__)

# Load the model, scaler, and columns
with open('model (1).pkl', 'rb') as f:
    model = pickle.load(f)

with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

with open('columns.pkl', 'rb') as f:
    columns = pickle.load(f)

# Extract location options from columns
location_columns = [col for col in columns if col.startswith('location_')]
LOCATION_OPTIONS = [col.replace('location_', '').replace('-', ' ').title() for col in location_columns]

# Remove target variable from feature columns
FEATURE_COLUMNS = [col for col in columns if col != 'Final Amount']

# HTML template with embedded CSS
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>TerraTrend</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #405DE6;
            --secondary-color: #5851DB;
            --accent-color: #833AB4;
            --gradient-start: #405DE6;
            --gradient-mid: #833AB4;
            --gradient-end: #E1306C;
            --light-bg: #fafafa;
            --dark-text: #262626;
            --light-text: #8e8e8e;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --danger-color: #e74c3c;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--dark-text);
            line-height: 1.6;
        }
        
        .header-container {
            background: linear-gradient(45deg, var(--gradient-start), var(--gradient-mid), var(--gradient-end));
            color: white;
            padding: 2.5rem 0;
            margin-bottom: 2rem;
            border-radius: 0;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .header-style {
            font-size: 3.5rem;  /* Increased font size */
            font-weight: 800;   /* Increased font weight */
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .subheader {
            font-size: 1.2rem;
            font-weight: 300;
            opacity: 0.9;
        }
        
        .section-header {
            font-size: 1.4rem;
            font-weight: 600;
            color: var(--accent-color);
            margin-top: 2rem;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--border-color);
        }
        
        .form-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2.5rem;
            background-color: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.05);
            margin-bottom: 3rem;
            border: 1px solid var(--border-color);
        }
        
        .results-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2.5rem;
            background-color: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.05);
            margin-bottom: 3rem;
            border: 1px solid var(--border-color);
        }
        
        .prediction-card {
            background: linear-gradient(45deg, rgba(64, 93, 230, 0.08), rgba(131, 58, 180, 0.08));
            padding: 2rem;
            border-radius: 12px;
            border-left: 5px solid var(--accent-color);
            margin-bottom: 2rem;
            text-align: center;
        }
        
        .price-display {
            font-size: 3rem;
            font-weight: 700;
            background: linear-gradient(45deg, var(--gradient-start), var(--gradient-mid), var(--gradient-end));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 0.5rem 0;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, var(--gradient-start), var(--gradient-mid));
            border: none;
            padding: 0.85rem 2rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            border-radius: 8px;
        }
        
        .btn-primary:hover {
            background: linear-gradient(45deg, var(--gradient-mid), var(--gradient-end));
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .btn-secondary {
            background-color: var(--light-text);
            border: none;
            padding: 0.85rem 2rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            border-radius: 8px;
        }
        
        .btn-secondary:hover {
            background-color: #6c757d;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .form-control, .form-select {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 0.75rem 1rem;
            background-color: var(--light-bg);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(64, 93, 230, 0.15);
        }
        
        .feature-icon {
            font-size: 2.5rem;
            background: linear-gradient(45deg, var(--gradient-start), var(--gradient-mid), var(--gradient-end));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 1rem;
        }
        
        .card {
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 100%;
            background-color: var(--card-bg);
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
        }
        
        .card-title {
            color: var(--accent-color);
            font-weight: 600;
        }
        
        .button-group {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .alert-info {
            background-color: rgba(64, 93, 230, 0.08);
            border-color: rgba(64, 93, 230, 0.2);
            color: var(--dark-text);
            border-radius: 8px;
        }
        
        footer {
            background-color: var(--card-bg);
            border-top: 1px solid var(--border-color);
        }
        
        .note-text {
            font-size: 0.9rem;
            color: var(--light-text);
            margin-top: 0.5rem;
        }
        
        @media (max-width: 576px) {
            .button-group {
                flex-direction: column;
            }
            
            .header-style {
                font-size: 2.5rem;  /* Adjusted for mobile */
            }
            
            .form-container, .results-container {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="header-container">
        <div class="container text-center">
            <h1 class="header-style">🏠 TerraTrend</h1>
            <p class="subheader">Estimate property prices based on various features</p>
        </div>
    </div>
    
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-center p-4">
                    <div class="feature-icon">📊</div>
                    <h3>Data-Driven</h3>
                    <p>Our predictions are based on analysis of thousands of property listings across multiple locations.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center p-4">
                    <div class="feature-icon">🎯</div>
                    <h3>Accurate</h3>
                    <p>Machine learning models trained on historical data ensure reliable price estimates.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center p-4">
                    <div class="feature-icon">⚡</div>
                    <h3>Actionable</h3>
                    <p>Get clear insights to make informed decisions about your real estate investments.</p>
                </div>
            </div>
        </div>
        
        <form method="POST" action="/predict" class="form-container">
            <div class="section-header">Property Information</div>
            
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <select class="form-select" id="location" name="location" required>
                    {% for location in location_options %}
                    <option value="{{ location }}">{{ location }}</option>
                    {% endfor %}
                </select>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="carpet_area" class="form-label">Carpet Area (sqft)</label>
                    <input type="number" class="form-control" id="carpet_area" name="carpet_area" min="1500" max="6000" value="2000" required>
                    <small class="text-muted">Must be between 1500 and 6000 sqft</small>
                </div>
                <div class="col-md-6">
                    <label for="super_area" class="form-label">Super Area (sqft)</label>
                    <input type="number" class="form-control" id="super_area" name="super_area" min="1800" max="6500" value="2200" required>
                    <small class="text-muted">Must be between 1800 and 6500 sqft</small>
                </div>
            </div>
            
            <div class="section-header">Property Details</div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="bhk" class="form-label">BHK</label>
                    <select class="form-select" id="bhk" name="bhk" required>
                        <option value="1">1</option>
                        <option value="2" selected>2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="bathroom" class="form-label">Bathroom</label>
                    <select class="form-select" id="bathroom" name="bathroom" required>
                        <option value="1">1</option>
                        <option value="2" selected>2</option>
                        <option value="3">3</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="balcony" class="form-label">Balcony</label>
                    <select class="form-select" id="balcony" name="balcony" required>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2" selected>2</option>
                    </select>
                </div>
            </div>
            
            <div class="section-header">Additional Features</div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="furnishing" class="form-label">Furnishing</label>
                    <select class="form-select" id="furnishing" name="furnishing" required>
                        <option value="1">Unfurnished</option>
                        <option value="2" selected>Semi-Furnished</option>
                        <option value="3">Fully Furnished</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="facing" class="form-label">Facing Direction</label>
                    <select class="form-select" id="facing" name="facing" required>
                        <option value="0">North</option>
                        <option value="1">East</option>
                        <option value="2">South</option>
                        <option value="3">West</option>
                        <option value="4" selected>North-East</option>
                        <option value="5">North-West</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="0">Under Construction</option>
                        <option value="1" selected>Ready to Move</option>
                    </select>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="transaction" class="form-label">Transaction Type</label>
                    <select class="form-select" id="transaction" name="transaction" required>
                        <option value="3" selected>New Property</option>
                        <option value="4">Resale</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="ownership" class="form-label">Ownership Type</label>
                    <select class="form-select" id="ownership" name="ownership" required>
                        <option value="0" selected>Freehold</option>
                        <option value="1">Leasehold</option>
                    </select>
                </div>
            </div>
            
            <div class="button-group">
                <button type="submit" class="btn btn-primary w-100 py-3 fw-bold">Predict Price</button>
                <a href="https://public.tableau.com/app/profile/santosh.kriplani/viz/Project2_17544349064900/Main?publish=yes" 
                   target="_blank" 
                   class="btn btn-secondary w-100 py-3 fw-bold">
                   Our Insights
                </a>
            </div>
        </form>
        
        {% if show_results %}
        <div class="results-container">
            <div class="section-header">Prediction Results</div>
            
            <div class="prediction-card">
                <div class="text-center">
                    <p class="mb-2">Estimated Price for Property in <strong>{{ location }}</strong></p>
                    <div class="price-display">{{ predicted_price }}</div>
                    <p class="note-text"><strong>Note:</strong> Predicted value is in lac</p>
                </div>
            </div>
            
            <h4 class="mt-4">Property Details</h4>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Carpet Area</h5>
                            <p class="card-text fs-4">{{ carpet_area }} sqft</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Super Area</h5>
                            <p class="card-text fs-4">{{ super_area }} sqft</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">BHK</h5>
                            <p class="card-text fs-4">{{ bhk }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Bathroom</h5>
                            <p class="card-text fs-4">{{ bathroom }}</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Recommendations</h5>
                    <div class="alert alert-info">
                        <strong>Tips to improve property value:</strong>
                        <ul class="mt-2">
                            <li>Consider adding a balcony (increases value by ~5%)</li>
                            <li>Upgrading to fully furnished can increase value by 10-15%</li>
                            <li>Properties in {{ optimal_location }} typically get 8% higher prices</li>
                            <li>South-facing properties are most preferred in this area</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        {% endif %}
    </div>

    <footer class="py-4 mt-5">
        <div class="container text-center">
            <p class="text-muted mb-0">TerraTrend &copy; 2023 | Data-Driven Insights for Property Investors</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        return predict()
    return render_template_string(HTML_TEMPLATE, 
                                show_results=False,
                                location_options=LOCATION_OPTIONS)

@app.route('/predict', methods=['POST'])
def predict():
    # Get form data
    location = request.form.get('location', 'Bangalore')
    carpet_area = float(request.form.get('carpet_area', 2000))
    super_area = float(request.form.get('super_area', 2200))
    bhk = int(request.form.get('bhk', 2))
    bathroom = int(request.form.get('bathroom', 2))
    balcony = int(request.form.get('balcony', 2))
    furnishing = int(request.form.get('furnishing', 2))
    facing = int(request.form.get('facing', 4))
    status = int(request.form.get('status', 1))
    transaction = int(request.form.get('transaction', 3))
    ownership = int(request.form.get('ownership', 0))
    
    # Validate input ranges
    if carpet_area < 1500 or carpet_area > 6000:
        return "Carpet Area must be between 1500 and 6000 sqft", 400
    if super_area < 1800 or super_area > 6500:
        return "Super Area must be between 1800 and 6500 sqft", 400
    
    # Prepare input data for prediction (excluding target variable)
    input_data = {
        'Price (in rupees)': 0,  # This is a feature, not the target
        'Carpet Area in sqft': carpet_area,
        'Status': status,
        'Transaction': transaction,
        'Furnishing': furnishing,
        'facing': facing,
        'Bathroom': bathroom,
        'Balcony': balcony,
        'Ownership': ownership,
        'BHK': bhk,
        'Super Area in sqft': super_area
    }
    
    # Add location columns (one-hot encoded)
    for loc in LOCATION_OPTIONS:
        col_name = 'location_' + loc.lower().replace(' ', '-')
        input_data[col_name] = 1 if loc == location else 0
    
    # Create DataFrame with features in correct order
    df = pd.DataFrame([input_data], columns=FEATURE_COLUMNS)
    
    # Scale the features
    scaled_features = scaler.transform(df)
    
    # Make prediction
    predicted_amount = model.predict(scaled_features)[0]
    
    # Format results
    formatted_amount = "{:,.2f}".format(predicted_amount)
    
    # Determine optimal location
    optimal_locations = {
        'Bangalore': 'Bangalore',
        'Mumbai': 'Mumbai',
        'Delhi': 'New Delhi',
        'Gurgaon': 'Gurgaon',
        'Hyderabad': 'Hyderabad'
    }
    optimal_location = optimal_locations.get(location, 'Bangalore')
    
    return render_template_string(HTML_TEMPLATE,
        show_results=True,
        location=location,
        predicted_price=formatted_amount,
        carpet_area=int(carpet_area),
        super_area=int(super_area),
        bhk=bhk,
        bathroom=bathroom,
        optimal_location=optimal_location,
        location_options=LOCATION_OPTIONS
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)
